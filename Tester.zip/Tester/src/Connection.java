import java.util.Random;
public class Connection {
	Phone serverPhone,clientPhone;

	OneWayDelay servToClient;
	OneWayDelay clientToServ;
	
	public Connection(Phone serverPhone, Phone clientPhone, OneWayDelay servToClient, OneWayDelay clientToServ){
		this.serverPhone = serverPhone;
		this.clientPhone = clientPhone;
		this.servToClient = servToClient;
		this.clientToServ = clientToServ;
		clientPhone.connect = this;
	}
	

	
	
	//Deprecated
	/*public Connection(int minDelayRangeBottom, int minDelayRangeTop, int meanDeviationRangeBottom, int meanDeviationRangeTop){
		minDelay = (int)Phone.randInt(minDelayRangeBottom, minDelayRangeTop);
		meanDeviation = (int)Phone.randInt(meanDeviationRangeBottom, meanDeviationRangeTop);
	}*/
		
	public long getActualOffset(){
		return Math.abs(serverPhone.clock-clientPhone.clock);
	}
	
	/*public long getSimulatedOffset(long proposedDelayInMillis){
		long currentTime = System.nanoTime();
		long firstPhoneClock = p1.clockValue();
		long proposedDelay = proposedDelayInMillis*1000000;
		while((System.nanoTime()-currentTime)<proposedDelay)
		{
			//loop until simulated delay is over.
		}
		System.out.println("proposedDelay was "+Long.toString(proposedDelay));
		long actualDelay = System.nanoTime()-currentTime;
		System.out.println("actualDelay was "+Long.toString(actualDelay));
		return p2.clockValue()-firstPhoneClock;
	}*/
	
	public long getOtherTimeStamp(Phone requestingPhone){
		long delay;
		if(requestingPhone==serverPhone){
			servToClient.simulateDelay();
			delay = clientPhone.sendTimeStampToConnection();
			clientToServ.simulateDelay();
			return delay;
		}
		else if (requestingPhone == clientPhone){
			clientToServ.simulateDelay();
			delay = serverPhone.sendTimeStampToConnection();
			servToClient.simulateDelay();
			return delay;
		}
		else
		{
			System.out.println("Error in connection setup.");
			return -1;
		}
	}
	
	public void setOffset(Phone requestingPhone){
		if(requestingPhone==serverPhone)
			clientPhone.estConnectedPhoneClockOffset = requestingPhone.estConnectedPhoneClockOffset;
		if(requestingPhone==clientPhone)
			serverPhone.estConnectedPhoneClockOffset = requestingPhone.estConnectedPhoneClockOffset;
	}
	
	public void printDetails(){
		System.out.println("     ---- Server Phone details ----");
		serverPhone.printDetails();
		System.out.println("\n     ---- Client Phone details ----");
		clientPhone.printDetails();
		System.out.println("\n     ---- servtoClient Connection details ----");
		servToClient.printDetails();
		System.out.println("\n     ---- clientToServ Connection details ----");
		clientToServ.printDetails();
		System.out.println("\n  actualOffset is "+Long.toString(getActualOffset()));
		System.out.println("\n  calculatedOffset is off by "+Long.toString(getActualOffset()-Math.abs(serverPhone.estConnectedPhoneClockOffset)));
	}
}