
public class OneWayDelay {
	int min;
	int meanDeviation;
	long longestDelay = 0;
	
	public OneWayDelay(int min, int meanDeviation){
		this.min = min;
		this.meanDeviation = meanDeviation;
	}
	
	public void simulateDelay(){
		
		long currentTime = System.nanoTime();
		long proposedDelay = (long) Phone.randInt(min,min+(meanDeviation))*1000000;
		while((System.nanoTime()-currentTime)<proposedDelay)
		{
			//loop until simulated delay is over.
		}
		if(proposedDelay>longestDelay)
			longestDelay = proposedDelay;
		
	}
	
	public void printDetails(){
		System.out.println("min is: " + Integer.toString(min));
		System.out.println("meanDeviation is: "+Integer.toString(meanDeviation));
		System.out.println("longestDelay was: "+Long.toString(longestDelay));
	}
}
