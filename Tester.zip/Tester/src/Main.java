import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;



public class Main {
	
	public static void main(String args[]){
		Phone p1 = new Phone();
		Phone p2 = new Phone();
		OneWayDelay servToClient = new OneWayDelay(2, 10);
		OneWayDelay clientToServ = new OneWayDelay(2, 10);
		Connection connect = p1.connect(p2,servToClient,clientToServ); 
		if(connect != null)
			connect.printDetails();

	}
}
