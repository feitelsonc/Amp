import java.util.Random;


public class Phone{
	long clock;

	
	Connection connect;
	long estConnectedPhoneClockOffset;
	
	public Phone(){
		Random rg = new Random();
		clock = rg.nextLong();
		if(clock<0)
			clock = clock*-1;
	}
	
	public Connection connect(Phone phone, OneWayDelay servToClient, OneWayDelay clientToServ){
		this.connect= new Connection(this, phone,servToClient, clientToServ);
		
		long bestTimeSoFar = Long.MAX_VALUE;
		long currentHandshakeTime;
		long connectionStartTime = System.nanoTime();
		long ogTime,myPhoneTimeStamp,offset;
		
		for(int i=0;i<1000;i++)
		{
			ogTime = System.nanoTime();			//In the actual algorithm, nanoTime is the same as the system nanoTime.
			myPhoneTimeStamp = this.nanoTime();
			offset = requestTimeStampFromConnection()-myPhoneTimeStamp;
			currentHandshakeTime = System.nanoTime()-ogTime;
			if(currentHandshakeTime<=5000000)
			{
				System.out.println("VALID TIME STAMP: delay below 5 milliseconds ");
				if(currentHandshakeTime<bestTimeSoFar)
				{
					bestTimeSoFar = currentHandshakeTime;
					this.estConnectedPhoneClockOffset = offset;
				}
			}
			else
			{
				if((System.nanoTime()-connectionStartTime)/1000000>10000){
					System.out.println("Connection clock sync handshake timeout.");
					break;
				}
			}
		}
		
		if(bestTimeSoFar<=5000000)
		{
			connect.setOffset(this);
			return this.connect;
		}
		else
		{
			System.out.println("No succesful clock sync handshake in 1000 attempts");
			return null;
		}
	}
	
	public Connection connectTrialRuns(Phone phone, OneWayDelay servToClient, OneWayDelay clientToServ,int numTrials){
		this.connect= new Connection(this, phone,servToClient, clientToServ);
		int count = 0;
		for(int i=0;i<numTrials;i++)
		{
			if(i%100==0)
			{
				System.out.println("i is: "+Integer.toString(i));
			}
			long ogTime = System.nanoTime();			//In the actual algorithm, nanoTime is the same as the system nanoTime.
			long myPhoneTimeStamp = this.nanoTime();
			long offset = requestTimeStampFromConnection()-myPhoneTimeStamp;
			if(System.nanoTime()-ogTime<=5000000)
			{
				this.estConnectedPhoneClockOffset = offset;
				count++;
			}
		}
		System.out.println("number of successes: "+Integer.toString(count));	
		return this.connect;
	}
	
	public void disconnect(){
		connect = null;
	}
	
	public boolean receiveConnection(Connection connect){
		if(this.connect==null)
		{
			this.connect = connect;
			return true;
		}
		else
			return false;
	}
	
	public long nanoTime(){
		return clock+System.nanoTime();
	}
	
	public long sendTimeStampToConnection(){
		return nanoTime();
	}
	
	public long requestTimeStampFromConnection(){
		return connect.getOtherTimeStamp(this);
	}
	

	public static int randInt(int min, int max) {

	    // NOTE: Usually this should be a field rather than a method
	    // variable so that it is not re-seeded every call.
	    Random rand = new Random();
	    // nextInt is normally exclusive of the top value,
	    // so add 1 to make it inclusive
	    int randomNum = rand.nextInt((max - min) + 1) + min;
	    return randomNum;
	}
	
	public void printDetails(){
		System.out.println("clock is: "+ Long.toString(clock));
		System.out.println("estConnectedPhoneClockOffset is: "+ Long.toString(estConnectedPhoneClockOffset));
	}
}
